/**
 * Created by dllo on 17/8/23.
 */
import React from 'react'
import ReactDOM from 'react-dom'
import DesignerShow from './DesignerShow'

ReactDOM.render(
  <DesignerShow />,
    document.getElementById('app')
)
