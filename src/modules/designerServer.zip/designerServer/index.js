/**
 * Created by dllo on 17/8/23.
 */
import React from 'react'
import ReactDOM from 'react-dom'
import DesignerServer from './DesignerServer'

ReactDOM.render(
  <DesignerServer />,
    document.getElementById('app')
)
